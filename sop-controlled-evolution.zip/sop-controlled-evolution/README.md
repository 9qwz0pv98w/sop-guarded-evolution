# SOP Guarded Evolution — execução isolada e promoção verificável

Versão prática do SOP: nove agentes podem editar todo o próprio pacote de políticas em uma cópia de staging, criar arquivos e executar Python arbitrário em um ambiente sem rede. O avaliador, o placar e a regra de promoção ficam fora do alcance do código candidato.

## Regra de promoção

Para cada agente e cada jogo do catálogo (jogos antigos **e** novos), o avaliador externo conta os erros/Game Overs antes da vitória. Só promove se todos os 9 agentes tiverem pontuação menor ou igual à versão ativa em todos os jogos e houver pelo menos uma melhora estrita. A comparação usa o mesmo segredo e os mesmos jogos. Empate geral não promove; uma regressão em uma única célula bloqueia tudo.

“Consciência” aqui significa continuidade de estado — código campeão, `memory.json`, descobertas, histórico e placar — não uma alegação de consciência ou experiência subjetiva.

## O que é, e o que não é

- Executa código Python arbitrário dentro de um contêiner Docker sem rede, com sistema de arquivos somente leitura, usuário não-root, sem capabilities, limites de CPU/memória/processos e timeout.
- Em modo de desenvolvimento, somente uma cópia temporária do pacote candidato é gravável; se o comando termina com sucesso e passa a auditoria de arquivos, as alterações voltam ao staging. O avaliador fixo roda depois com o candidato montado somente para leitura.
- Não monta diretórios pessoais, credenciais, socket do Docker ou arquivos do avaliador no contêiner.
- Isso **não** torna um contêiner equivalente a uma VM nem oferece garantia absoluta contra falhas do kernel. Use a execução interativa apenas em uma VM descartável. O workflow de CI roda em runner hospedado e efêmero; o contêiner do candidato continua sem rede.
- Não inclui uma conexão automática com um agente Notion/LLM. O agente precisa ter uma ferramenta autorizada que invoque os comandos CLI abaixo. O repositório fornece a interface e o protocolo.
- Instalar dependências durante a execução é proibido pela ausência de rede. Dependências devem ser revisadas e incorporadas à imagem confiável antes da avaliação.

## Início rápido

```bash
docker build -t sop-agent-sandbox:local -f package/sandbox/Dockerfile package/sandbox
PYTHONPATH=package python3 -m sop.cli init --workspace ./sop-work
PYTHONPATH=package SOP_IMAGE=sop-agent-sandbox:local python3 -m sop.cli status --workspace ./sop-work
```

Editar/executar o candidato dentro do sandbox (sem shell implícito):

```bash
PYTHONPATH=package SOP_IMAGE=sop-agent-sandbox:local python3 -m sop.cli exec \
  --workspace ./sop-work -- python3 propose_midpoint.py
```

Avaliar; adicionar `--promote` para promover automaticamente somente após o gate passar:

```bash
PYTHONPATH=package SOP_IMAGE=sop-agent-sandbox:local python3 -m sop.cli evaluate \
  --workspace ./sop-work --candidate ./sop-work/staging --promote
```

Adicionar um novo jogo sem apagar os antigos:

```bash
PYTHONPATH=package python3 -m sop.cli add-game \
  --workspace ./sop-work --id jogo-10 --bits 8
```

O estado privado do catálogo é criado em `sop-work/state/`; mantenha esse diretório fora do Git. O segredo de desafio nunca é montado no contêiner.

## Passo a passo para um agente

1. Leia `package/docs/AGENT_PROTOCOL.md` e `package/docs/MATH_FOUNDATIONS.md`.
2. Trabalhe apenas em `sop-work/staging`. O agente pode reescrever `agents.py`, adicionar módulos, testes e atualizar `memory.json`.
3. Execute código chamando `sop.cli exec` com uma lista de argumentos. Exemplo acima. A execução não tem Internet; saída diferente de zero ou arquivos fora dos limites descarta a cópia.
4. Faça o agente explicar a hipótese, a mudança, os testes e os resultados em um relatório; não aceite os resultados que o próprio candidato declara como prova.
5. Rode `evaluate`. O juiz usa os movimentos reais, não uma pontuação autodeclarada pelo agente.
6. Somente com `--promote` e gate aprovado o pacote candidato inteiro vira uma nova versão. Se falhar, a versão ativa e seu estado permanecem intactos.
7. Repita com novos jogos adicionados ao catálogo. A regra reavalia todos os jogos, não apenas o jogo novo.

## GitHub Actions

O workflow `.github/workflows/validate.yml` constrói a imagem e executa testes de integração no runner efêmero do GitHub. A etapa de checkout/build usa a Internet do runner; os processos do agente são executados em contêineres com `--network=none`. Não há Codespace, token de agente, segredo de repositório nem serviço pago configurado.

Mais detalhes: `package/docs/SETUP.md`, `package/docs/AGENT_PROTOCOL.md`, `package/docs/MATH_FOUNDATIONS.md` e `package/docs/ORTHOGONAL_METHODS.md`.
