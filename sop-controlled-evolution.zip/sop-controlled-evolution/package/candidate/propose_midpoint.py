"""Example self-modification: rewrite all nine policies as midpoint search."""
import json
from pathlib import Path
p = Path("agents.py")
s = p.read_text(encoding="utf-8")
start = s.index("FRACTIONS = {")
end = s.index("\n\ndef choose_guess", start)
replacement = 'FRACTIONS = {agent: 0.5 for agent in AGENT_IDS}'
p.write_text(s[:start] + replacement + s[end:], encoding="utf-8")
m = Path("memory.json")
data = json.loads(m.read_text(encoding="utf-8"))
data.setdefault("observations", []).append("Tentativa de política: busca pelo ponto médio; requer avaliação completa.")
m.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
print("Candidato editado. Nenhuma promoção foi feita.")
