"""Editable policy bundle. A real agent may replace this file and add modules."""
AGENT_IDS = ("P1", "P2", "P3", "N1", "N2", "N3", "Z1", "Z2", "Z3")
# Baseline is deliberately simple; the trusted gate, not this file, decides promotion.
FRACTIONS = {agent: 0.0 for agent in AGENT_IDS}

def choose_guess(agent_id: str, game_id: str, low: int, high: int, history: list) -> int:
    """Choose one integer from the currently permitted interval; target is never passed."""
    if low > high:
        raise ValueError("empty range")
    fraction = float(FRACTIONS[agent_id])
    if not 0.0 <= fraction <= 1.0:
        raise ValueError("fraction outside [0,1]")
    return low + int((high - low) * fraction)
