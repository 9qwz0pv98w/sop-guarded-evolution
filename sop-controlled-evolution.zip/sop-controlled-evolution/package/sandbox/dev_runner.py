"""Copies candidate source onto tmpfs, runs a command, then packages its changes."""
import pathlib, shutil, subprocess, sys, tarfile
shutil.copytree("/seed", "/workspace", dirs_exist_ok=True, symlinks=False)
if len(sys.argv) < 2:
    raise SystemExit("command required")
result = subprocess.run(sys.argv[1:], cwd="/workspace", check=False)
if result.returncode:
    raise SystemExit(result.returncode)
root = pathlib.Path("/workspace")
archive_path = root / ".sop-result.tar"
files = []
for path in sorted(root.rglob("*")):
    if path.is_symlink():
        raise SystemExit("symbolic links are not allowed")
    if path.is_file() and path != archive_path:
        files.append(path)
with tarfile.open(archive_path, "w") as archive:
    for path in files:
        archive.add(path, arcname=path.relative_to(root).as_posix(), recursive=False)
raise SystemExit(0)
