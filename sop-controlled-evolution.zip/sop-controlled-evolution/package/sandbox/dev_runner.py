"""Copies a starter package onto bounded tmpfs and runs its command without a shell."""
import os, shutil, subprocess, sys
shutil.copytree("/seed", "/workspace", dirs_exist_ok=True, symlinks=False)
if len(sys.argv) < 2:
    raise SystemExit("command required")
raise SystemExit(subprocess.run(sys.argv[1:], cwd="/workspace", check=False).returncode)
