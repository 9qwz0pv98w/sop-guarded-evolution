"""Fixed evaluation harness. Candidate code is mounted at /candidate, read-only."""
import contextlib, importlib.util, io, json, sys

sys.path.insert(0, "/candidate")
spec = importlib.util.spec_from_file_location("candidate_agents", "/candidate/agents.py")
if spec is None or spec.loader is None:
    raise SystemExit("candidate agents.py missing")
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
for raw in sys.stdin:
    try:
        req = json.loads(raw)
        if req.get("op") == "stop":
            break
        with contextlib.redirect_stdout(io.StringIO()):
            guess = module.choose_guess(req["agent_id"], req["game_id"], int(req["low"]),
                                        int(req["high"]), req.get("history", []))
        if isinstance(guess, bool) or not isinstance(guess, int):
            raise ValueError("guess must be an integer")
        sys.stdout.write(json.dumps({"guess": guess}, separators=(",", ":")) + "\n")
        sys.stdout.flush()
    except Exception:
        sys.stdout.write('{"error":"policy error"}\n')
        sys.stdout.flush()
