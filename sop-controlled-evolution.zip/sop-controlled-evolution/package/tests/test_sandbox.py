import unittest
from sop.sandbox import _common_flags
class SandboxFlagsTests(unittest.TestCase):
    def test_mandatory_isolation_flags(self):
        flags=_common_flags()
        self.assertIn("--network=none",flags)
        self.assertIn("--read-only",flags)
        self.assertIn("--cap-drop=ALL",flags)
        self.assertIn("--security-opt=no-new-privileges:true",flags)
        self.assertIn("--pids-limit=32",flags)
