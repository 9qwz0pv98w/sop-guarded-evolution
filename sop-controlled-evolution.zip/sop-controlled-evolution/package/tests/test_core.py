import json, os, tempfile, unittest
from pathlib import Path
from sop.metrics import compare_score_matrices
from sop.orthogonal import hadamard, dot, reflect
from sop.compression import compress, decompress
from sop.reward import streak_multiplier
from sop.engine import AGENTS
from sop.sandbox import SandboxSession
from unittest.mock import patch

class CoreTests(unittest.TestCase):
    def test_gate_all_cells_and_strict_improvement(self):
        agents, games = ("A", "B"), ("old", "new")
        old = {a: {g: 4 for g in games} for a in agents}
        equal = compare_score_matrices(old, old, agents, games)
        self.assertFalse(equal.eligible)
        new = {a: dict(v) for a, v in old.items()}; new["A"]["new"] = 3
        self.assertTrue(compare_score_matrices(old, new, agents, games).eligible)
        new["B"]["old"] = 5
        result = compare_score_matrices(old, new, agents, games)
        self.assertFalse(result.eligible); self.assertTrue(any("regressão" in e for e in result.errors))

    def test_missing_and_bad_scores_block(self):
        r = compare_score_matrices({"A": {"g": 1}}, {"A": {"g": -1}}, ("A",), ("g",))
        self.assertFalse(r.eligible)

    def test_hadamard_is_orthogonal_and_involutive(self):
        a, b = hadamard([1, 0, 0, 0]), hadamard([0, 1, 0, 0])
        self.assertAlmostEqual(dot(a, b), 0.0)
        self.assertAlmostEqual(sum(x*x for x in a), 1.0)

    def test_reflection_preserves_norm(self):
        x=[1.0,2.0,3.0]; y=reflect(x,[1.0,0.0,0.0])
        self.assertAlmostEqual(sum(v*v for v in x),sum(v*v for v in y))

    def test_compression_roundtrip_and_raw_fallback(self):
        for raw in (b"abc", b"x"*10000, bytes(range(256))):
            self.assertEqual(decompress(compress(raw)), raw)

    def test_reward_is_bounded(self):
        self.assertEqual(streak_multiplier(0), 1.0)
        self.assertLess(streak_multiplier(10**6), 5.0)
        self.assertGreater(streak_multiplier(10**6), 4.99)

    def test_roster_has_nine_agents(self): self.assertEqual(len(AGENTS), 9)

    def test_protocol_consumes_each_response_once(self):
        class Pipe:
            def fileno(self): return 7
            def write(self, _): pass
            def flush(self): pass
        class Process:
            stdin = Pipe()
            stdout = Pipe()
            def poll(self): return None
        session = SandboxSession.__new__(SandboxSession)
        session.proc = Process()
        session.timeout = 1
        session.buffer = bytearray()
        chunks = iter((b'{"guess":1}\n', b'{"guess":2}\n'))
        with patch("sop.sandbox.select.select", side_effect=lambda *args: ([args[0][0]], [], [])), patch("sop.sandbox.os.read", side_effect=lambda *args: next(chunks)):
            self.assertEqual(session.request({}), {"guess":1})
            self.assertEqual(session.request({}), {"guess":2})

@unittest.skipUnless(os.environ.get("SOP_RUN_DOCKER_TESTS") == "1", "Docker integration runs in CI")
class DockerIntegrationTests(unittest.TestCase):
    def test_offline_edit_and_protected_promotion(self):
        from sop.engine import init_workspace, evaluate_with_targets
        from sop.sandbox import exec_candidate
        image=os.environ["SOP_IMAGE"]
        with tempfile.TemporaryDirectory() as td:
            root=Path(td)/"work"
            starter=Path(__file__).parents[1]/"candidate"/"agents.py"
            init_workspace(root,starter)
            # The policy runs in a no-network container; network connection must fail.
            (root/"staging"/"offline_check.py").write_text(
                "import socket\ntry:\n socket.create_connection(('1.1.1.1',443),timeout=.5)\n raise SystemExit('network unexpectedly available')\nexcept OSError:\n pass\nopen('proof.txt','w').write('offline')\n", encoding="utf-8")
            output=exec_candidate(root/"staging",["python3","offline_check.py"],image,10)
            self.assertEqual((root/"staging"/"proof.txt").read_text(),"offline")
            (root/"staging"/"offline_check.py").unlink()
            (root/"staging"/"proof.txt").unlink()
            # The agent modifies its full candidate bundle inside the no-network container.
            exec_candidate(root/"staging",["python3","propose_midpoint.py"],image,10)
            games=json.loads((root/"state"/"gamebook.json").read_text())[:2]
            targets={g["id"]: (1 << (g["bits"]-1)) - 1 for g in games}
            report=evaluate_with_targets(root,root/"staging",image,games,targets,True)
            self.assertEqual(report["checked_cells"],len(AGENTS)*len(games))
            self.assertEqual(len(report["candidate"]),9)
            self.assertTrue(report["eligible"])
            self.assertTrue(report["promoted"])
            self.assertEqual((root/"state"/"active_version.txt").read_text().strip(),"v000001")
