# Semente matemática para agentes

Este guia fornece uma base para formular ideias, não substitui livros nem prova que uma ideia é verdadeira. Um agente deve definir termos, escrever hipóteses, procurar contraexemplos, demonstrar lemas e registrar testes reprodutíveis.

## 1. Linguagem, conjuntos e ZFC

Uma definição matemática começa por um domínio (quais objetos existem), relações/operações e regras de inferência. Um conjunto é uma coleção determinada de objetos; `x ∈ A` significa pertinência. Operações: união `A∪B`, interseção `A∩B`, diferença `A\\B`, produto cartesiano `A×B`, conjunto das partes `P(A)`. Relações como `⊆` e igualdade devem ser definidas por extensionalidade: `A=B` se e somente se todo elemento de A pertence a B e vice-versa.

ZFC (Zermelo–Fraenkel com escolha) é uma fundação amplamente usada, organizada em axiomas/esquemas — extensionalidade, conjunto vazio, par, união, partes, infinito, separação, substituição, regularidade e escolha. Não é correto dizer que toda matemática necessariamente “nasce” só de ZFC: existem outras fundações e teorias de tipos. Em trabalhos formais, explicite qual fundação está usando.

## 2. Prova, dedução, indução e abdução

- **Dedução:** de premissas e regras válidas, deriva uma conclusão necessária. Ex.: `n é múltiplo de 4 ⇒ n é par`; prova: `n=4k=2(2k)`.
- **Indução matemática:** provar base `P(0)` e passo `P(n)⇒P(n+1)` para concluir `P(n)` em todos os naturais. Indução forte permite usar todos os casos anteriores.
- **Indução empírica:** generalizar observações finitas; gera hipótese, não prova universal.
- **Abdução:** escolher a explicação plausível que melhor explica observações; gera hipótese revisável, não prova.

Código pode procurar contraexemplos em domínios finitos e verificar cálculos; isso não prova automaticamente afirmações sobre infinitos.

## 3. Lógica booleana e De Morgan

Booleanos `0/1` com `¬`, `∧`, `∨`. Tabelas verdade são a semântica básica; por exemplo, `A∧B` é 1 só quando ambos são 1. Leis de De Morgan:

- `¬(A∧B) = (¬A)∨(¬B)`
- `¬(A∨B) = (¬A)∧(¬B)`

Para conjuntos: `A\\(B∪C)=(A\\B)∩(A\\C)` e `A\\(B∩C)=(A\\B)∪(A\\C)`.

## 4. Mapas de Karnaugh

Para uma função booleana com poucas variáveis, organize as combinações em grade com ordem Gray (células adjacentes diferem em um bit). Agrupe 1s em blocos de tamanho potência de dois, permitindo envolvimento pelas bordas. Cada grupo elimina variáveis que mudam dentro do grupo. O resultado simplifica circuitos; confira sempre equivalência comparando todas as linhas da tabela verdade. Para muitos bits, use minimizadores algorítmicos, não mapa manual.

## 5. Equações e construção de novas matemáticas

Equação é uma afirmação de igualdade sob um domínio e regras dadas. Para solucionar: (1) declarar domínio e restrições; (2) transformar mantendo equivalência; (3) testar casos-limite; (4) substituir a solução na equação original; (5) demonstrar unicidade/existência se necessário.

Para propor uma nova estrutura matemática: declare objetos, operações, axiomas e exemplos; verifique consistência local, fechamento, identidade, inversos e propriedades desejadas; derive resultados passo a passo; procure modelos e contraexemplos; compare com estruturas conhecidas; não confunda uma notação nova com uma teoria nova. Testes finitos são evidência, não prova geral.

## 6. Ortogonalidade e álgebra linear

Vetores `a,b` são ortogonais sob produto interno se `<a,b>=0`. Para vetores reais, o produto interno euclidiano é `Σ a_i b_i`. A transformada de Hadamard normalizada `H_n` (ordem potência de 2) satisfaz `H_n^T H_n=I`; ela muda de base, não comprime automaticamente. Reflexões de Householder `x' = x - 2 (x·v)/(v·v) v` preservam norma para `v≠0`.

“Grau de ortogonalidade” personalizado precisa de definição precisa: domínio, operação, associação, quantificadores e igualdade. Se a operação mistura soma/produto, escreva cada quantificador e teste contra exemplos. Não deduza uma nova hierarquia só por analogia com logaritmos.

## 7. Números reais, duais, complexos e hiperbólicos

- Reais: `log_b(x)` exige `b>0`, `b≠1`, `x>0`; `log_{b^z}(x)=log_b(x)/z` quando a potência/base está definida e é válida.
- Duais: `ε²=0`; para `a>0`, `ln(a+bε)=ln(a)+(b/a)ε` por expansão finita. Útil para derivadas algébricas, não introduz ordem total compatível com todas operações.
- Complexos: exponencial é periódica; logaritmo é multivalorado. Identidades com log exigem escolha de ramo e termos `2πik`; identidades reais não podem ser copiadas sem controlar ramos.
- Hiperbólicos/split-complex: `j²=1`, com idempotentes `(1±j)/2`; há divisores de zero e regiões sem inverso. Verifique inversibilidade antes de dividir.
- `i²=-1`; portanto `|x|i²=-|x|` nos complexos, mas exponenciação/logaritmo de base negativa exige controle de ramos. `i²` não é “metade de i”.

## 8. Aprendizagem e evidência

Especifique alvo, métrica, orçamento e teste fora da amostra. Separe treino/validação/teste; não use respostas do avaliador durante treino. Mantenha seeds determinísticas, versão do código e resultados. Evite vazamento do alvo. Para perda ruidosa, investigue o limite de irreducibilidade; não prometa loss zero em toda tarefa. Aprimoramento exige evidência no domínio testado e não prova superioridade universal.
