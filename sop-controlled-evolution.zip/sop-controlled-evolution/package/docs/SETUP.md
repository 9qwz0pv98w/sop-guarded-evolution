# Instalação e execução

## Opção A — validar online no GitHub Actions

O repositório inclui workflow para `push`, pull request e execução manual (`workflow_dispatch`). Ao subir código, o runner Ubuntu efêmero constrói a imagem e executa testes de integração. O runner precisa baixar a imagem-base Python; isso acontece fora do contêiner do candidato. O código do agente roda dentro de Docker com `--network=none`.

Não crie Codespace para executar testes se não quiser incorrer em uso de cota/cobrança. O workflow usa runner hospedado padrão. Para trabalho realmente automático contínuo, conecte um orquestrador autorizado ao workflow via integração revisada; não coloque token GitHub no candidato.

## Opção B — VM descartável

1. Crie uma VM descartável Linux sem dados pessoais ou credenciais.
2. Instale Docker Engine e Python 3.10+; use um usuário sem privilégios de administrador.
3. Clone o repositório e construa a imagem confiável:

   ```bash
   docker build -t sop-agent-sandbox:local -f package/sandbox/Dockerfile package/sandbox
   ```

4. Inicialize o estado:

   ```bash
   PYTHONPATH=package python3 -m sop.cli init --workspace ./sop-work
   ```

5. Verifique status e execute um teste candidato:

   ```bash
   PYTHONPATH=package SOP_IMAGE=sop-agent-sandbox:local python3 -m sop.cli status --workspace ./sop-work
   PYTHONPATH=package SOP_IMAGE=sop-agent-sandbox:local python3 -m sop.cli exec --workspace ./sop-work -- python3 propose_midpoint.py
   ```

6. Avalie e promova apenas se o controlador aprovar:

   ```bash
   PYTHONPATH=package SOP_IMAGE=sop-agent-sandbox:local python3 -m sop.cli evaluate --workspace ./sop-work --candidate ./sop-work/staging --promote
   ```

7. Acrescente novo jogo e repita. A mesma suíte antiga permanece no conjunto de avaliação:

   ```bash
   PYTHONPATH=package python3 -m sop.cli add-game --workspace ./sop-work --id jogo-novo --bits 8
   ```

## Criar integração para um agente

A ferramenta do agente deve invocar somente `sop.cli exec` e `sop.cli evaluate` com argumentos fixos; não dê um terminal do host ao agente. A integração pode expor operações de alto nível: `ler staging`, `executar script no sandbox`, `avaliar candidato`, `consultar relatório`. Não exponha `state/challenge_key.bin` nem permita comandos Docker arbitrários. O agente não deve ser o autor e o aprovador da própria pontuação: o juiz confiável continua externo.
