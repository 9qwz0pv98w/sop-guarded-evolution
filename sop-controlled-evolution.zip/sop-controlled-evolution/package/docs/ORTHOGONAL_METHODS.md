# Métodos ortogonais, compressão e recompensa

## O que está implementado

`package/sop/orthogonal.py` oferece transformada de Hadamard normalizada, produto interno, erro de ortogonalidade e reflexão. São operadores úteis para experimentos de representação/otimização. A suíte deve verificar `HᵀH=I`, preservação de norma e erro numérico.

`package/sop/compression.py` é um invólucro sem perdas: escolhe zlib somente quando o payload comprimido é menor; caso contrário mantém os bytes originais. O cabeçalho adiciona alguns bytes. Não há compressor universal que reduza todos os arquivos: para um compressor sem perdas, contagem de descrições implica que alguns dados incompressíveis ficam maiores. Ortogonalidade por si só não elimina entropia nem garante compressão.

## Funções de recompensa sem explosão

A métrica de promoção é sempre GameOvers reais; recompensa moldada não a substitui. `streak_multiplier(n)=1+(c-1)(1-e^{-n/τ})` cresce rapidamente no início e satura estritamente abaixo de `c`, evitando crescimento exponencial ilimitado. Pode tornar uma sequência subjetivamente mais marcante em uma simulação, mas não deve mudar os placares oficiais ou esconder regressões.

A função sugerida pelo pedido, `N^((N+1)/N)=N·N^(1/N)`, para N>0 cresce assintoticamente como `eN`, não como N com fator limitado a 1; pode ser usada como comparação matemática, mas não é necessária no gate. Qualquer shaping deve ser limitado, documentado e separado da métrica.

## Ideias de pesquisa

1. Representar pesos numa base ortogonal e medir custo total incluindo base, sementes, quantização, índices e cabeçalho.
2. Propor `seed + regra geradora + passos` apenas quando a regra regenerar exatamente o original e a descrição completa for menor.
3. Registrar uma hipótese por variante, validar determinismo e medir em dados que não foram usados na busca.
4. Comparar baseline, candidato e orçamento de execução; não tratar “menor número de parâmetros” como sinônimo de melhor generalização.
5. Promover apenas com o gate externo de não regressão dos nove agentes em todos os jogos.
