# Protocolo operacional dos agentes

## Capacidades e fronteiras

O agente controla integralmente os arquivos em `staging` (Python, módulos auxiliares, testes e `memory.json`). Ele pode criar novas matemáticas/algoritmos como hipóteses e executar programas nesse pacote. `sop.cli exec` cria uma cópia temporária sobre tmpfs, sem shell implícito e sem rede; o pacote só volta ao staging se o comando terminar com código 0 e todos os arquivos passarem a auditoria. A cópia é limitada a 100 arquivos, 1 MB por arquivo e 4 MB no total.

O agente **não** altera o juiz confiável, a geração dos alvos secretos, o catálogo protegido, a política Docker, os placares ou a regra de promoção. Isso é deliberado: se o candidato pudesse modificar o juiz que o aprova, o resultado não seria prova independente.

## Protocolo de ciclo

1. Leia estado/descobertas (`memory.json`) e formule uma hipótese testável.
2. Altere qualquer código sob o pacote de candidato. Não edite o juiz.
3. Execute testes somente pelo sandbox: `python -m sop.cli exec --workspace WORK -- python3 SEU_TESTE.py`.
4. Solicite avaliação externa completa: `python -m sop.cli evaluate --workspace WORK --candidate WORK/staging`.
5. Use `--promote` apenas quando a mudança estiver pronta. O controlador compara os nove agentes, cada jogo antigo e cada jogo novo, usando o mesmo desafio secreto.
6. Registre em `memory.json` o que funcionou, hipótese, evidência e versão. Essa memória só passa a integrar a versão ativa quando a promoção é aprovada.
7. Se a mudança falhar, não force o juiz. Revise a hipótese e tente outra proposta.

## Protocolo de agente autônomo

Um orquestrador autorizado pode repetir: observar relatório → gerar uma hipótese → escrever no staging → executar código sem rede → avaliar → promover somente pelo gate. Cada iteração deve ter limite de tempo, número de propostas e tamanho de artefatos. Não conceda ao orquestrador acesso ao diretório `state/` nem ao host; apenas a CLI confiável precisa desses caminhos.

O exemplo `propose_midpoint.py` demonstra uma autoedição real do pacote candidato. É uma demonstração de alteração, não uma promessa de que essa política passará no placar secreto. Nenhuma promoção é presumida.

## Semântica do jogo e métrica

Cada jogo esconde um inteiro em `[0, 2^bits-1]`. O agente escolhe um palpite. Um palpite errado termina a tentativa como Game Over e revela somente se o alvo era maior ou menor; os limites públicos são reduzidos. `GameOvers` é a quantidade de palpites errados antes do acerto. O alvo deriva de uma chave privada guardada no estado do controlador; chave e alvo nunca entram no contêiner. Essa mecânica é um benchmark didático substituível, não representa todos os jogos possíveis.

A aceitação é uma comparação Pareto por célula `(agente, jogo)`: `novo <= ativo` em todas; ao menos uma célula deve melhorar estritamente. Faltar uma célula, saída inválida, timeout, resposta malformada ou regressão bloqueia a promoção inteira. Jogos novos entram junto com todos os antigos.

## Segurança e ameaças

A ausência de rede e os limites reduzem risco, mas contêineres compartilham o kernel do host. Para código de origem desconhecida, use runner hospedado efêmero ou VM descartável, mantenha o Docker atualizado e nunca monte credenciais, home pessoal, socket Docker ou dados de clientes. Não faça `pip install` dentro do sandbox. A imagem é código confiável; revise e fixe as alterações nela.
