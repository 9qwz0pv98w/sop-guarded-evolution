"""Docker sandbox. The trusted controller never mounts secrets into candidate containers."""
from __future__ import annotations
import json, os, select, shutil, signal, subprocess, tempfile, time, uuid
from pathlib import Path

MAX_FILES = 100
MAX_FILE_BYTES = 1_000_000
MAX_TREE_BYTES = 4_000_000
MAX_LINE_BYTES = 8192

class SandboxError(RuntimeError):
    pass


def audit_tree(root: Path) -> None:
    root = root.resolve(strict=True)
    if not root.is_dir() or root.is_symlink():
        raise SandboxError("O pacote candidato deve ser uma pasta real.")
    count = total = 0
    for p in root.rglob("*"):
        if p.is_symlink():
            raise SandboxError(f"Link simbólico não permitido: {p.name}")
        if p.is_dir():
            continue
        if not p.is_file():
            raise SandboxError(f"Tipo de arquivo não permitido: {p.name}")
        count += 1
        size = p.stat().st_size
        total += size
        if size > MAX_FILE_BYTES or count > MAX_FILES or total > MAX_TREE_BYTES:
            raise SandboxError("Limite de quantidade/tamanho do pacote excedido.")


def _common_flags(user: str = "65532:65532", file_size: int = 1_048_576) -> list[str]:
    return ["--network=none", "--read-only", "--cap-drop=ALL",
            "--security-opt=no-new-privileges:true", "--pids-limit=32",
            "--memory=256m", "--memory-swap=256m", "--cpus=1",
            "--user", user, "--tmpfs", "/tmp:rw,nosuid,nodev,noexec,size=16m",
            "--ulimit", "nofile=64:64", "--ulimit", f"fsize={file_size}:{file_size}",
            "--env", "PYTHONDONTWRITEBYTECODE=1", "--env", "HOME=/tmp"]


def _read_process(proc: subprocess.Popen, timeout: float, limit: int = 65536) -> tuple[int, bytes, bytes]:
    streams = {proc.stdout: bytearray(), proc.stderr: bytearray()}
    output = {proc.stdout: bytearray(), proc.stderr: bytearray()}
    for stream in streams:
        os.set_blocking(stream.fileno(), False)
    deadline = time.monotonic() + timeout
    while streams or proc.poll() is None:
        remaining = deadline - time.monotonic()
        if remaining <= 0:
            os.killpg(proc.pid, signal.SIGKILL)
            proc.wait()
            for stream in output:
                stream.close()
            raise SandboxError("Tempo limite excedido; contêiner encerrado.")
        ready, _, _ = select.select([s for s in streams], [], [], min(remaining, 0.1))
        for stream in ready:
            try:
                chunk = os.read(stream.fileno(), 8192)
            except BlockingIOError:
                continue
            if not chunk:
                streams.pop(stream, None)
                continue
            buf = output[stream]
            buf.extend(chunk)
            if sum(len(b) for b in output.values()) > limit:
                os.killpg(proc.pid, signal.SIGKILL)
                proc.wait()
                for pipe in output:
                    pipe.close()
                raise SandboxError("Saída excedeu o limite; contêiner encerrado.")
    code = proc.wait()
    stdout, stderr = bytes(output[proc.stdout]), bytes(output[proc.stderr])
    for stream in output:
        stream.close()
    return code, stdout, stderr


class SandboxSession:
    """One no-network container process; JSONL requests contain observations only."""
    def __init__(self, candidate: str | Path, image: str, timeout: float = 2.0):
        path = Path(candidate)
        audit_tree(path)
        self.timeout = timeout
        self.proc = subprocess.Popen(
            ["docker", "run", "--rm", "-i", *_common_flags(),
             "--mount", f"type=bind,src={path.resolve()},dst=/candidate,readonly",
             image, "python3", "/opt/runner.py"],
            stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
            bufsize=0, start_new_session=True)
        self.buffer = bytearray()

    def request(self, observation: dict) -> dict:
        if self.proc.poll() is not None:
            raise SandboxError("O processo candidato terminou inesperadamente.")
        try:
            self.proc.stdin.write((json.dumps(observation, separators=(",", ":")) + "\n").encode())
            self.proc.stdin.flush()
        except (BrokenPipeError, OSError) as e:
            raise SandboxError("Falha no canal do sandbox.") from e
        fd = self.proc.stdout.fileno()
        deadline = time.monotonic() + self.timeout
        while True:
            if b"\n" in self.buffer:
                line, remainder = self.buffer.split(b"\n", 1)
                if remainder:
                    self.close(force=True)
                    raise SandboxError("Resposta extra/fora do protocolo.")
                self.buffer.clear()
                try:
                    response = json.loads(line)
                except Exception as e:
                    raise SandboxError("Resposta JSON inválida do agente.") from e
                if not isinstance(response, dict) or "guess" not in response:
                    raise SandboxError("Resposta não contém guess inteiro.")
                return response
            if len(self.buffer) > MAX_LINE_BYTES:
                self.close(force=True)
                raise SandboxError("Resposta excedeu o limite de tamanho.")
            remaining = deadline - time.monotonic()
            if remaining <= 0 or not select.select([self.proc.stdout], [], [], max(0, remaining))[0]:
                self.close(force=True)
                raise SandboxError("Agente excedeu o timeout por ação.")
            chunk = os.read(fd, 4096)
            if not chunk:
                raise SandboxError("Fim inesperado do canal do agente.")
            self.buffer.extend(chunk)

    def close(self, force: bool = False) -> None:
        if self.proc.poll() is None:
            if not force:
                try:
                    self.proc.stdin.close()
                    self.proc.wait(timeout=1)
                except Exception:
                    force = True
            if force and self.proc.poll() is None:
                os.killpg(self.proc.pid, signal.SIGKILL)
                self.proc.wait()
        if self.proc.stdout and not self.proc.stdout.closed:
            self.proc.stdout.close()

    def __enter__(self): return self
    def __exit__(self, *_): self.close()


def exec_candidate(candidate: str | Path, command: list[str], image: str,
                   timeout: float = 20.0) -> str:
    """Run arbitrary code against a disposable tmpfs copy, then audit and sync back."""
    if not command:
        raise SandboxError("Informe o comando do agente após --.")
    source = Path(candidate).resolve(strict=True)
    audit_tree(source)
    if "," in str(source):
        raise SandboxError("O caminho do candidato não pode conter vírgula.")
    parent = source.parent
    tmpfs_root = Path("/dev/shm")
    if not tmpfs_root.is_dir() or not os.access(tmpfs_root, os.W_OK):
        raise SandboxError("A execução requer um /dev/shm gravável (tmpfs Linux).")
    workdir = Path(tempfile.mkdtemp(prefix=".sop-work-", dir=tmpfs_root)).resolve()
    workdir.chmod(0o700)
    output = Path(tempfile.mkdtemp(prefix=".sop-result-", dir=parent)).resolve()
    container_name = "sop-dev-" + uuid.uuid4().hex[:12]
    try:
        create = ["docker", "create", "--name", container_name, *_common_flags(f"{os.getuid()}:{os.getgid()}"),
                  "--mount", f"type=bind,src={source},dst=/seed,readonly",
                  "--mount", f"type=bind,src={workdir},dst=/workspace",
                  "--workdir", "/workspace", "--entrypoint", "python3", image,
                  "/opt/dev_runner.py", *command]
        made = subprocess.run(create, capture_output=True, text=True, timeout=30)
        if made.returncode:
            raise SandboxError("Docker não conseguiu criar sandbox: " + made.stderr[-1000:])
        proc = subprocess.Popen(["docker", "start", "-a", container_name], stdout=subprocess.PIPE,
                                stderr=subprocess.PIPE, start_new_session=True)
        code, stdout, stderr = _read_process(proc, timeout)
        if code:
            raise SandboxError(f"Comando saiu com código {code}; staging não foi alterado.\n{stderr.decode(errors='replace')[-2000:]}")
        # The editable workspace is a dedicated host tmpfs bind mount, so its
        # contents persist after the container stops but never touch disk.
        audit_tree(workdir)
        result = output
        shutil.copytree(workdir, result, dirs_exist_ok=True, symlinks=True)
        audit_tree(result)
        if not (result / "agents.py").is_file() or not (result / "memory.json").is_file():
            raise SandboxError("O agente precisa preservar agents.py e memory.json.")
        backup = parent / (".sop-backup-" + uuid.uuid4().hex[:8])
        os.replace(source, backup)
        try:
            os.replace(result, source)
        except Exception:
            os.replace(backup, source)
            raise
        shutil.rmtree(backup)
        return stdout.decode(errors="replace")[-4000:]
    finally:
        subprocess.run(["docker", "rm", "-f", container_name], capture_output=True, timeout=10)
        shutil.rmtree(output, ignore_errors=True)
        shutil.rmtree(workdir, ignore_errors=True)
