"""Lossless convenience wrapper: compression is used only when it saves bytes."""
import zlib
MAGIC = b"SOP1"

def compress(data: bytes, level: int = 9) -> bytes:
    packed = zlib.compress(data, level)
    if len(packed) < len(data):
        return MAGIC + b"Z" + packed
    return MAGIC + b"R" + data

def decompress(blob: bytes) -> bytes:
    if not blob.startswith(MAGIC) or len(blob) < 5:
        raise ValueError("invalid SOP1 stream")
    if blob[4:5] == b"Z": return zlib.decompress(blob[5:])
    if blob[4:5] == b"R": return blob[5:]
    raise ValueError("unknown SOP1 encoding")
