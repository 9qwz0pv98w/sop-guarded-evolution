"""Small, exact orthogonal transforms for experiments; not a universal compressor."""
import math

def hadamard(values):
    x = [float(v) for v in values]
    n = len(x)
    if n == 0 or n & (n - 1): raise ValueError("length must be a positive power of two")
    width = 1
    while width < n:
        for start in range(0, n, width * 2):
            for j in range(start, start + width):
                a, b = x[j], x[j + width]
                x[j], x[j + width] = a + b, a - b
        width *= 2
    scale = math.sqrt(n)
    return [v / scale for v in x]

def dot(a, b):
    if len(a) != len(b): raise ValueError("dimension mismatch")
    return sum(float(x) * float(y) for x, y in zip(a, b))

def orthogonal_error(a, b): return abs(dot(a, b))

def reflect(vector, normal):
    denom = dot(normal, normal)
    if denom == 0: raise ValueError("normal cannot be zero")
    scale = 2 * dot(vector, normal) / denom
    return [float(v) - scale * float(n) for v, n in zip(vector, normal)]
