"""Trusted, per-agent/per-game non-regression gate."""
from dataclasses import dataclass
from typing import Mapping, Sequence

@dataclass(frozen=True)
class GateResult:
    eligible: bool
    strict_improvements: int
    checked_cells: int
    errors: tuple[str, ...]


def compare_score_matrices(incumbent: Mapping[str, Mapping[str, int]],
                           candidate: Mapping[str, Mapping[str, int]],
                           agents: Sequence[str], games: Sequence[str]) -> GateResult:
    errors: list[str] = []
    improvements = 0
    cells = 0
    for agent in agents:
        for game in games:
            cells += 1
            if agent not in incumbent or game not in incumbent[agent]:
                errors.append(f"incumbent ausente: {agent}/{game}")
                continue
            if agent not in candidate or game not in candidate[agent]:
                errors.append(f"candidato ausente: {agent}/{game}")
                continue
            old, new = incumbent[agent][game], candidate[agent][game]
            if isinstance(old, bool) or not isinstance(old, int) or old < 0:
                errors.append(f"placar incumbent inválido: {agent}/{game}")
                continue
            if isinstance(new, bool) or not isinstance(new, int) or new < 0:
                errors.append(f"placar candidato inválido: {agent}/{game}")
                continue
            if new > old:
                errors.append(f"regressão: {agent}/{game}: {old} -> {new}")
            elif new < old:
                improvements += 1
    return GateResult(not errors and improvements > 0, improvements, cells, tuple(errors))
