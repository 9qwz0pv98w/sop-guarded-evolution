"""Trusted host-side judge; target generation and scorekeeping never enter the sandbox."""
from __future__ import annotations
import hashlib, hmac, json, os, re, shutil, time
from pathlib import Path
from .metrics import compare_score_matrices
from .sandbox import SandboxSession, audit_tree

AGENTS = ("P1", "P2", "P3", "N1", "N2", "N3", "Z1", "Z2", "Z3")
DEFAULT_GAMES = [{"id": f"game-{i:02d}", "bits": 5 + (i % 4)} for i in range(1, 10)]


def atomic_json(path: Path, value) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_name(path.name + ".tmp")
    temp.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    os.replace(temp, path)


def init_workspace(workspace: str | Path, starter: str | Path) -> None:
    root = Path(workspace).resolve()
    if root.exists() and any(root.iterdir()):
        raise ValueError("workspace já existe e não está vazio")
    root.mkdir(parents=True, exist_ok=True)
    (root / "versions").mkdir(exist_ok=True)
    (root / "state").mkdir(exist_ok=True)
    active = root / "versions" / "v000000"
    shutil.copytree(Path(starter).resolve().parent, active)
    audit_tree(active)
    seed = os.urandom(32)
    secret = root / "state" / "challenge_key.bin"
    secret.write_bytes(seed)
    secret.chmod(0o600)
    atomic_json(root / "state" / "gamebook.json", DEFAULT_GAMES)
    atomic_json(root / "state" / "ledger.json", {"promotions": [], "created_at": time.time()})
    (root / "state" / "active_version.txt").write_text("v000000\n", encoding="utf-8")
    shutil.copytree(active, root / "staging")


def active_path(root: Path) -> Path:
    ver = (root / "state" / "active_version.txt").read_text(encoding="utf-8").strip()
    path = root / "versions" / ver
    if not path.is_dir():
        raise ValueError("versão ativa ausente")
    return path


def add_game(root: Path, game_id: str, bits: int) -> None:
    if not re.fullmatch(r"[A-Za-z0-9_-]{1,40}", game_id):
        raise ValueError("id deve conter apenas letras, números, _ ou -")
    if not 1 <= bits <= 16:
        raise ValueError("bits deve estar entre 1 e 16")
    path = root / "state" / "gamebook.json"
    games = json.loads(path.read_text(encoding="utf-8"))
    if any(g["id"] == game_id for g in games):
        raise ValueError("id de jogo já existe")
    games.append({"id": game_id, "bits": bits})
    atomic_json(path, games)


def challenge_targets(root: Path, games: list[dict]) -> dict[str, int]:
    key = (root / "state" / "challenge_key.bin").read_bytes()
    out = {}
    for game in games:
        digest = hmac.new(key, game["id"].encode(), hashlib.sha256).digest()
        out[game["id"]] = int.from_bytes(digest[:8], "big") % (1 << int(game["bits"]))
    return out


def score_candidate(candidate: Path, games: list[dict], targets: dict[str, int], image: str,
                    timeout: float = 2.0) -> dict[str, dict[str, int]]:
    scores: dict[str, dict[str, int]] = {}
    for agent in AGENTS:
        scores[agent] = {}
        with SandboxSession(candidate, image, timeout) as session:
            for game in games:
                game_id, bits = game["id"], int(game["bits"])
                low, high, history, failures = 0, (1 << bits) - 1, [], 0
                target = targets[game_id]
                for _ in range(1 << bits):
                    result = session.request({"agent_id": agent, "game_id": game_id,
                                              "low": low, "high": high, "history": history})
                    guess = result.get("guess")
                    if isinstance(guess, bool) or not isinstance(guess, int) or not low <= guess <= high:
                        raise ValueError(f"ação inválida de {agent} em {game_id}")
                    if guess == target:
                        scores[agent][game_id] = failures
                        break
                    failures += 1
                    direction = "higher" if guess < target else "lower"
                    history.append({"guess": guess, "feedback": direction})
                    if direction == "higher": low = guess + 1
                    else: high = guess - 1
                else:
                    raise ValueError(f"{agent} não venceu {game_id} dentro do limite")
    return scores


def _tree_hash(folder: Path) -> str:
    digest = hashlib.sha256()
    for path in sorted(p for p in folder.rglob("*") if p.is_file()):
        digest.update(path.relative_to(folder).as_posix().encode())
        digest.update(path.read_bytes())
    return digest.hexdigest()


def evaluate_with_targets(root: Path, candidate: Path, image: str, games: list[dict],
                          targets: dict[str, int], promote: bool = False) -> dict:
    root = root.resolve(); candidate = candidate.resolve()
    audit_tree(candidate)
    if not (candidate / "agents.py").is_file() or not (candidate / "memory.json").is_file():
        raise ValueError("candidato precisa conter agents.py e memory.json")
    old = score_candidate(active_path(root), games, targets, image)
    new = score_candidate(candidate, games, targets, image)
    result = compare_score_matrices(old, new, AGENTS, [g["id"] for g in games])
    report = {"timestamp": time.time(), "games": [g["id"] for g in games],
              "agents": list(AGENTS), "incumbent": old, "candidate": new,
              "eligible": result.eligible, "strict_improvements": result.strict_improvements,
              "checked_cells": result.checked_cells, "errors": list(result.errors),
              "candidate_sha256": _tree_hash(candidate), "promoted": False}
    atomic_json(root / "state" / "last_report.json", report)
    if promote and result.eligible:
        versions = sorted((root / "versions").glob("v[0-9]*"))
        next_id = f"v{len(versions):06d}"
        destination = root / "versions" / next_id
        shutil.copytree(candidate, destination)
        audit_tree(destination)
        pointer = root / "state" / "active_version.txt"
        temp = pointer.with_suffix(".tmp")
        temp.write_text(next_id + "\n", encoding="utf-8")
        os.replace(temp, pointer)
        ledger_path = root / "state" / "ledger.json"
        ledger = json.loads(ledger_path.read_text(encoding="utf-8"))
        ledger["promotions"].append({"version": next_id, "timestamp": report["timestamp"],
                                     "sha256": report["candidate_sha256"],
                                     "scores": new, "strict_improvements": result.strict_improvements})
        atomic_json(ledger_path, ledger)
        report["promoted"] = True
        report["version"] = next_id
        atomic_json(root / "state" / "last_report.json", report)
    return report


def evaluate(root: Path, candidate: Path, image: str, promote: bool = False) -> dict:
    root = root.resolve()
    games = json.loads((root / "state" / "gamebook.json").read_text(encoding="utf-8"))
    targets = challenge_targets(root, games)
    return evaluate_with_targets(root, candidate, image, games, targets, promote)
