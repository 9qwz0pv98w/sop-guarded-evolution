"""SOP guarded agent evolution toolkit."""
__version__ = "1.0.0"
