"""Command line entry point: python -m sop.cli <command>."""
import argparse, json, os
from pathlib import Path
from .engine import add_game, active_path, evaluate, init_workspace
from .sandbox import exec_candidate, SandboxError


def main(argv=None):
    p = argparse.ArgumentParser(prog="sopctl")
    sub = p.add_subparsers(dest="action", required=True)
    q = sub.add_parser("init"); q.add_argument("--workspace", required=True); q.add_argument("--starter")
    q = sub.add_parser("status"); q.add_argument("--workspace", required=True)
    q = sub.add_parser("add-game"); q.add_argument("--workspace", required=True); q.add_argument("--id", required=True); q.add_argument("--bits", type=int, required=True)
    q = sub.add_parser("exec"); q.add_argument("--workspace", required=True); q.add_argument("--candidate"); q.add_argument("--timeout", type=float, default=20); q.add_argument("command", nargs=argparse.REMAINDER)
    q = sub.add_parser("evaluate"); q.add_argument("--workspace", required=True); q.add_argument("--candidate"); q.add_argument("--image", default=os.environ.get("SOP_IMAGE", "sop-agent-sandbox:local")); q.add_argument("--promote", action="store_true")
    a = p.parse_args(argv)
    try:
        root = Path(a.workspace).resolve()
        if a.action == "init":
            starter = Path(a.starter).resolve() if a.starter else Path(__file__).resolve().parents[1] / "candidate" / "agents.py"
            init_workspace(root, starter); print(f"Workspace criado: {root}")
        elif a.action == "status":
            version = (root / "state" / "active_version.txt").read_text().strip()
            games = json.loads((root / "state" / "gamebook.json").read_text())
            print(json.dumps({"active_version": version, "games": len(games), "staging": str(root / "staging")}, ensure_ascii=False))
        elif a.action == "add-game":
            add_game(root, a.id, a.bits); print(f"Jogo adicionado: {a.id} ({a.bits} bits)")
        elif a.action == "exec":
            command = a.command[1:] if a.command[:1] == ["--"] else a.command
            candidate = Path(a.candidate).resolve() if a.candidate else root / "staging"
            print(exec_candidate(candidate, command, os.environ.get("SOP_IMAGE", "sop-agent-sandbox:local"), a.timeout))
        elif a.action == "evaluate":
            candidate = Path(a.candidate).resolve() if a.candidate else root / "staging"
            report = evaluate(root, candidate, a.image, a.promote)
            print(json.dumps({"eligible": report["eligible"], "promoted": report["promoted"],
                              "version": report.get("version"), "strict_improvements": report["strict_improvements"],
                              "checked_cells": report["checked_cells"], "errors": report["errors"]}, ensure_ascii=False, indent=2))
            if not report["eligible"]: return 2
        return 0
    except (ValueError, OSError, SandboxError) as e:
        print(f"ERRO: {e}")
        return 1

if __name__ == "__main__":
    raise SystemExit(main())
