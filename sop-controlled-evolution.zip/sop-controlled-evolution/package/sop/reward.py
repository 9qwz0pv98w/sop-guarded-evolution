"""Bounded display shaping; never used by the protected promotion metric."""
import math

def streak_multiplier(streak: int, ceiling: float = 5.0, tau: float = 2.0) -> float:
    """Saturating multiplier in [1, ceiling); zero streak is exactly 1."""
    if streak < 0 or ceiling < 1 or tau <= 0: raise ValueError("invalid shaping parameters")
    value = 1.0 + (ceiling - 1.0) * (1.0 - math.exp(-streak / tau))
    # Avoid floating-point rounding to the exact ceiling for very long streaks.
    return min(value, math.nextafter(float(ceiling), 1.0))

def shaped_reward(base: float, streak: int, outcome: str) -> float:
    """Strengthen the feel of runs while keeping objective value/acceptance separate."""
    if outcome not in {"win", "loss"}: raise ValueError("outcome must be win or loss")
    return base * streak_multiplier(streak)
